import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { 
  Home, 
  ArrowLeft, 
  ArrowRight, 
  RotateCw, 
  Bookmark, 
  Menu,
  Mic,
  Search
} from 'lucide-react';
import { motion } from 'motion/react';
import { useFocusManagement } from '../hooks/useFocusManagement';

interface ControlButtonProps {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  focusKey: string;
}

function ControlButton({ icon, label, onClick, focusKey }: ControlButtonProps) {
  const [isFocused, setIsFocused] = useState(false);

  const { elementRef } = useFocusManagement({
    focusKey,
    onEnter: onClick,
    onFocus: () => setIsFocused(true),
    onBlur: () => setIsFocused(false),
  });

  return (
    <motion.button
      ref={elementRef}
      tabIndex={0}
      onClick={onClick}
      className="flex flex-col items-center justify-center gap-3 p-6 rounded-2xl bg-gray-800/80 outline-none"
      animate={{
        scale: isFocused ? 1.1 : 1,
        backgroundColor: isFocused ? 'rgba(59, 130, 246, 0.3)' : 'rgba(31, 41, 55, 0.8)',
      }}
      transition={{ duration: 0.2 }}
      style={{
        boxShadow: isFocused
          ? '0 0 30px rgba(59, 130, 246, 0.8)'
          : '0 4px 6px rgba(0, 0, 0, 0.3)',
        border: isFocused ? '3px solid #3b82f6' : '3px solid transparent',
      }}
      aria-label={label}
    >
      {icon}
      <span className="text-lg">{label}</span>
    </motion.button>
  );
}

export function BrowserScreen() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [currentUrl, setCurrentUrl] = useState(searchParams.get('url') || 'https://www.google.com');
  const [urlInput, setUrlInput] = useState(currentUrl);
  const [isFocused, setIsFocused] = useState(false);

  useEffect(() => {
    const url = searchParams.get('url');
    if (url) {
      setCurrentUrl(url);
      setUrlInput(url);
    }
  }, [searchParams]);

  const { elementRef: urlBarRef } = useFocusManagement({
    focusKey: 'url-bar',
    onEnter: () => {
      if (urlInput.trim()) {
        setCurrentUrl(urlInput);
      }
    },
    onFocus: () => setIsFocused(true),
    onBlur: () => setIsFocused(false),
  });

  const handleBack = () => {
    // In a real browser, this would go back in history
    console.log('Back pressed');
  };

  const handleForward = () => {
    // In a real browser, this would go forward in history
    console.log('Forward pressed');
  };

  const handleRefresh = () => {
    // In a real browser, this would reload the page
    console.log('Refresh pressed');
  };

  const handleHome = () => {
    navigate('/');
  };

  const handleBookmark = () => {
    console.log('Bookmark added');
  };

  const handleMenu = () => {
    navigate('/settings');
  };

  return (
    <div className="min-h-screen bg-[#0F0F0F] text-white flex flex-col">
      {/* URL Bar */}
      <header className="px-8 py-6 bg-gray-900/50 backdrop-blur-lg">
        <motion.div
          ref={urlBarRef}
          tabIndex={0}
          autoFocus
          className="flex items-center gap-6 bg-gray-800/80 rounded-2xl px-8 py-5 outline-none"
          animate={{ scale: isFocused ? 1.02 : 1 }}
          transition={{ duration: 0.2 }}
          style={{
            boxShadow: isFocused
              ? '0 0 40px rgba(59, 130, 246, 0.6)'
              : '0 4px 8px rgba(0, 0, 0, 0.5)',
            border: isFocused ? '4px solid #3b82f6' : '4px solid transparent',
          }}
        >
          <Search className="w-8 h-8 text-gray-400 flex-shrink-0" />
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && urlInput.trim()) {
                setCurrentUrl(urlInput);
              }
            }}
            className="flex-1 bg-transparent text-white text-2xl outline-none"
            placeholder="Enter URL or search..."
          />
          <button className="p-2 hover:bg-gray-700 rounded-full transition-colors">
            <Mic className="w-8 h-8 text-blue-400" />
          </button>
        </motion.div>
      </header>

      {/* Web Content Area */}
      <main className="flex-1 bg-gray-900 m-8 rounded-3xl overflow-hidden relative">
        <div className="w-full h-full flex items-center justify-center">
          <div className="text-center space-y-6">
            <div className="w-32 h-32 mx-auto bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl flex items-center justify-center">
              <Search className="w-16 h-16" />
            </div>
            <div>
              <h2 className="text-4xl mb-4">Simulated Browser View</h2>
              <p className="text-2xl text-gray-400 mb-2">Current URL:</p>
              <p className="text-xl text-blue-400 break-all px-8">{currentUrl}</p>
            </div>
            <p className="text-xl text-gray-500">
              In a real browser, web content would display here
            </p>
          </div>
        </div>
      </main>

      {/* Floating Controls */}
      <footer className="px-8 pb-8">
        <div className="flex justify-center gap-6">
          <ControlButton
            icon={<ArrowLeft className="w-10 h-10" />}
            label="Back"
            onClick={handleBack}
            focusKey="back"
          />
          <ControlButton
            icon={<ArrowRight className="w-10 h-10" />}
            label="Forward"
            onClick={handleForward}
            focusKey="forward"
          />
          <ControlButton
            icon={<RotateCw className="w-10 h-10" />}
            label="Refresh"
            onClick={handleRefresh}
            focusKey="refresh"
          />
          <ControlButton
            icon={<Home className="w-10 h-10" />}
            label="Home"
            onClick={handleHome}
            focusKey="home"
          />
          <ControlButton
            icon={<Bookmark className="w-10 h-10" />}
            label="Bookmark"
            onClick={handleBookmark}
            focusKey="bookmark"
          />
          <ControlButton
            icon={<Menu className="w-10 h-10" />}
            label="Menu"
            onClick={handleMenu}
            focusKey="menu"
          />
        </div>
      </footer>
    </div>
  );
}
